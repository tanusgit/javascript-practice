$("#content").append("<strong>JavaScript is working!</strong>");

